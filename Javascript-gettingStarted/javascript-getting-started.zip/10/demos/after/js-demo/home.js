'use strict';

const productId = 1234;

console.log(productId);