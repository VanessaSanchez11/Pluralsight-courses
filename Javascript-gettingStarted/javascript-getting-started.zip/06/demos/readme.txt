Here are the before and after projects for this module of JavaScript Getting Started.
Be sure to watch the course to understand how to set up a project.

Execute:  npm install
then:     npm start

These commands will update the node_modules folder and start the liveserver, showing the web page in a browser.


