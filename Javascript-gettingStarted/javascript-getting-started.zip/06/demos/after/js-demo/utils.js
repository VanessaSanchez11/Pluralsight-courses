function showMessage(message) {
    document.getElementById('message').textContent = message;
}