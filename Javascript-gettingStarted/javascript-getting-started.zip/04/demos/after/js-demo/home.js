


let price = 25;

showMessage(price);
console.log(price);